#!/usr/bin/env python

nombre_str = input("Como te llamas?")
print("Hola " + nombre_str)